import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Publicacion } from '../interfaces';

@Component({
  selector: 'app-registrar-publicacion',
  templateUrl: './registrar-publicacion.component.html',
  styleUrls: ['./registrar-publicacion.component.css']
})
export class RegistrarPublicacionComponent implements OnInit {
 
  publicacionForm: FormGroup;

  constructor(private fb: FormBuilder) {

    this.publicacionForm = this.fb.group({
      PostId: [0, Validators.required],
      Titulo: ['', [Validators.required, Validators.maxLength(200)]],
      Contenido: ['', Validators.required],
      FechaPublicacion: ['', Validators.required],
      UserId: [0, Validators.required],
      Usuario: this.fb.group({
        UsuarioId: [0, Validators.required],
        Nombre: ['', Validators.required]
      })
    });

  }

  ngOnInit(): void {
    this.publicacionForm = this.fb.group({
      PostId: [0, Validators.required],
      Titulo: ['', [Validators.required, Validators.maxLength(200)]],
      Contenido: ['', Validators.required],
      FechaPublicacion: ['', Validators.required],
      UserId: [0, Validators.required],
      Usuario: this.fb.group({
        UsuarioId: [0, Validators.required],
        Nombre: ['', Validators.required]
      })
    });
  }

  onSubmit(): void {
    if (this.publicacionForm.valid) {
      const publicacion: Publicacion = this.publicacionForm.value;
      console.log(publicacion);
    }
  }
}
