export interface Login {
    username : string;
    password : string;
}


export interface Response {
    token : string;
    usuario : Usuario;
}


export interface Usuario {

    UserId : number;
    UserName : string;
    Email : string;
    Password : string;
    Publicaciones? : Publicacion[];
}


export interface Publicacion {
    PostId : number;
    Titulo : string;
    Contenido : string;
    FechaPublicacion : Date;
    UserId : number;
    Usuario : Usuario;
}