import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Login, Response } from '../interfaces';
import { ServiciosService } from '../servicios.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  login: Login = {
    username: '',
    password: '',
  };

  response : Response = {
    token : '',
    usuario : {
      UserId : 0,
      UserName : '',
      Email : '',
      Password : '',
      Publicaciones : []
    }

  }

  constructor(
    private formBuilderService: FormBuilder,
    private service: ServiciosService,
    private router: Router
  ) {
    this.loginForm = this.formBuilderService.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
  }

  ngOnInit(): void {
    let form = document.querySelector('form') as HTMLFormElement;
    form.addEventListener('submit', (submitEvent: SubmitEvent) => {
      if (!form.checkValidity()) {
        submitEvent.preventDefault();
        submitEvent.stopPropagation();
      }

      form.classList.add('was-validated');
    });
  }

  ingresar() {
    this.login.username = this.loginForm.get('username')?.value;
    this.login.password = this.loginForm.get('password')?.value;

    this.service.login(this.login).subscribe(data =>{

     console.log(data);

      



      if(data != null){
        localStorage.setItem('token',this.response.token);
        localStorage.setItem('usuario',JSON.stringify(this.response.usuario));
        this.router.navigate(['/home']);
      }

      this.router.navigate(['/home']);
    })




  }
}
