import { Component, OnInit } from '@angular/core';
import { ServiciosService } from '../servicios.service';
import { Router } from '@angular/router';
import { Publicacion } from '../interfaces';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent  implements OnInit{

publicaciones : Publicacion[] = [];
  
  constructor(
    private service: ServiciosService,
    private router: Router
  ) {}


  ngOnInit(): void {

    this.service.listarPublicaciones().subscribe(data =>{

      this.publicaciones = data;
    })


  }







}
