import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Login, Publicacion } from './interfaces';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiciosService {


  constructor(private http : HttpClient) { }


  login(user : Login):Observable<Response>{
    return this.http.post<Response>('https://localhost:7022/api/Usuario/login',user);
  }

  listarPublicaciones():Observable<Publicacion[]>{
    return this.http.get<Publicacion[]>('https://localhost:7022/api/Publicacion');
  }





}
